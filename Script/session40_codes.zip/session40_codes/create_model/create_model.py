# -*- coding: utf-8 -*-
"""
Created on Sun Oct 31 10:59:51 2021

@author: ganjar alfian
@email : ganjaralfian@gmail.com
"""

import pandas as pd
#from sklearn.pipeline import make_pipeline, Pipeline
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer


import numpy as np
from sklearn import metrics
from sklearn.metrics import plot_confusion_matrix
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
#from imblearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, OrdinalEncoder
#from imblearn.over_sampling import SMOTE
from sklearn.ensemble import RandomForestClassifier

df = pd.read_csv('bank.csv', delimiter=',')

df_X = df.drop(['deposit'],axis=1)
df_y = df[['deposit']]

le = LabelEncoder()
df_y= le.fit_transform(df_y['deposit'])

nums = df_X.select_dtypes(include=['int64', 'float64']).columns
#cats = df_X.select_dtypes(include=['object', 'bool']).columns
cats = ['job', 'marital', 'education', 'default', 'housing', 'loan', 'contact',
       'month', 'poutcome']

X_train, X_test, y_train, y_test = train_test_split(
    df_X, df_y, test_size=0.2, random_state=42)

numerical_transformer = SimpleImputer(strategy='median')
categorical_transformer = Pipeline(steps=[('imputer', SimpleImputer(strategy='most_frequent')),
                                          ('imput', OrdinalEncoder())])

preprocessor = ColumnTransformer(
transformers=[
('num', numerical_transformer, nums),
('cat', categorical_transformer, cats)
])

pipeline = Pipeline(steps=[('preprocessor', preprocessor), ('scaling', StandardScaler()), 
                           #('feature_selection', SelectFromModel(ExtraTreesClassifier(random_state=2), prefit=False)),
                           ('classifier', RandomForestClassifier(random_state=42, max_depth=10))])


pipeline = pipeline.fit(X_train, y_train)
filename = 'trained_model.pkl'
joblib.dump(pipeline, filename)

import pandas as pd
import joblib
from flask import Flask, redirect, url_for, request, render_template

app = Flask(__name__)
#load index.html/ first page. receive input variable from user
@app.route("/")
def index():
	return render_template('index.html')

#load result.html. the result of prediction is presented here. 
@app.route('/result/', methods=["POST"])
def prediction_result():
    #receiving parameters sent by client
    age = int(request.form.get('age'))
    job = request.form.get('job')
    marital = request.form.get('marital')
    education = request.form.get('education')
    default = request.form.get('default')
    balance = int(request.form.get('balance'))
    housing = request.form.get('housing')
    loan = request.form.get('loan')
    contact = request.form.get('contact')
    day = int(request.form.get('day'))
    month = request.form.get('month')
    duration = int(request.form.get('duration'))
    campaign = int(request.form.get('campaign'))
    pdays = int(request.form.get('pdays'))
    previous = int(request.form.get('previous'))
    poutcome = request.form.get('poutcome')
    
    
    #load the trained model.
    filename = 'trained_model.pkl'
    loaded_model= joblib.load(filename)
    #create new dataframe
    data = {'age':age, 'job':job, 'marital':marital, 'education':education, 'default':default, 'balance':balance, 'housing':housing,
           'loan':loan, 'contact':contact, 'day':day, 'month':month, 'duration':duration, 'campaign':campaign, 'pdays':pdays,
           'previous':previous, 'poutcome':poutcome}
    #pd.set_option('display.max_columns', None)
    #pd.set_option('display.max_rows', None)
    df_input = pd.DataFrame(data, index=[0])
    #print(df_input.dtypes)
    result = loaded_model.predict(df_input)
    #print(result)
    for i in result:
      int_result = int(i)
      if (int_result == 0):
        decision = 'No'
      elif (int_result==1):
        decision = 'Yes'
      else:
        decision = 'Not defined'
    #return the output and load result.html
    return render_template('result.html', status=decision)

if __name__ == "__main__":
    #host= ip address, port = port number
    #app.run(host='127.0.0.1', port='5001')
    app.run()
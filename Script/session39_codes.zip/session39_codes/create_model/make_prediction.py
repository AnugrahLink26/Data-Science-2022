# -*- coding: utf-8 -*-
"""
Created on Sun Oct 31 13:50:16 2021

@author: Ganjar Alfian
"""

import joblib
import pandas as pd

filename = 'trained_model.pkl'
loaded_model = joblib.load(filename)

data = {'age':68, 'job':'admin.', 'marital':'married', 'education':'secondary', 
        'default':'no', 'balance':2000, 'housing':'yes','loan':'no', 'contact':'unknown', 
        'day':5, 'month':'may', 'duration':1000, 'campaign':1, 'pdays':-1,
        'previous':0, 'poutcome':'unknown'}
df_input = pd.DataFrame(data, index=[0])
result = loaded_model.predict(df_input)

for i in result:
  int_result = int(i)
  if (int_result == 0):
    decision = 'No'
  elif (int_result==1):
    decision = 'Yes'
  else:
    decison = 'Not defined'

print('Possibility to deposit is ', decision)